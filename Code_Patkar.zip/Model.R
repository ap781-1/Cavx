#Model functions 

#Engel's CaViaR estimation: Symmetric absolute value model with x-specification
#ft(β) = β1 + β2 ft−1(β)+ β3|yt−1|+ β4xt−1

#parameter estimation function using GMLE method and loss function

parestim_base<- function(par, returns, alpha){
  beta1 <- par[1]#for base model we have 3 parameters, beta4 equals 0
  beta2 <- par[2]
  beta3 <- par[3]
  
  n <- length(returns)
  q<- numeric(n)
  q[1]<-quantile(returns, probs = alpha)
  for (t in 2:n){
    q[t] <- beta1 + beta2* q[t-1] + beta3 * abs(returns[t-1])
  }
  hit <- (returns < q)
  loss <- (alpha - hit) * (returns - q)
  
  return(sum(loss)) 
}
 

parestim_cavx<- function(par, returns, alpha, specx){
  beta1 <- par[1]
  beta2 <- par[2]
  beta3 <- par[3]
  beta4 <- par[4]
  
  n <- length(returns)
  q<- numeric(n)
  q[1]<-quantile(returns, probs = alpha)
  for (t in 2:n){
    q[t] <- beta1 + beta2* q[t-1] + beta3 * abs(returns[t-1]) + beta4 * specx[t]
  }
  cav <- sum((alpha - (returns < q)) * (returns - q))
  if(is.na(cav) | is.infinite(cav)) res <- 1e+10  # Check if 'cav' is either NA (missing) or infinite; if true, assign a large value (1e+10) to 'res'. A common practice
  else res <- cav
  return(cav)
}
#Forecast function for the base model
Forecastcav_base<- function(par, returns, alpha){
  beta1 <- par[1]
  beta2 <- par[2]
  beta3 <- par[3]
  
  n <- length(returns)
  q<- numeric(n)
  q<-quantile(returns, probs = alpha)
  
  for (t in 2:n){
    q[t] <- beta1 + beta2* q[t-1] + beta3 * abs(returns[t-1])
  }
  return(q)
}
#For forecasting the model with exogenous variable 
Forecastcav_x<- function(par, returns, alpha, specx){
  beta1 <- par[1]
  beta2 <- par[2]
  beta3 <- par[3]
  beta4 <- par[4]
  
  n <- length(returns)
  q<- numeric(n)
  q<-quantile(returns, probs = alpha)
  
  for (t in 2:n){
    q[t] <- beta1 + beta2* q[t-1] + beta3 * abs(returns[t-1]) + beta4 * specx[t-1]
  }
  return(q)
}

#Forecasting functions
#function for the base model
OutForecastcav_base<- function(par, returns, alpha, insam){
  beta1 <- par[1]
  beta2 <- par[2]
  beta3 <- par[3]
  
  n <- length(returns)
  q<- numeric(n)
  q<-tail(insam,1) #we use the tail values for insample forecast. It is the last value of the insample forecast. It is common practice.
  
  for (t in 2:n){
    q[t] <- beta1 + beta2* q[t - 1] + beta3 * abs(returns[t-1])
  }
  return(q)
  hit <- (returns < q)
  loss <- (1 - alpha) * (hit)*(returns-q) + (alpha) * (1 - hit)*(q-returns)
  return(sum(loss))
}

#Function for forecasting the model with exogenous variable
OutForecastcav_x <- function(par, returns, alpha, insam, specx){
  beta1 <- par[1]
  beta2 <- par[2]
  beta3 <- par[3]
  beta4 <- par[4]
  
  n <- length(returns)
  q <- numeric(n)
  q[1] <- tail(insam, 1)  # Set the initial value of q based on insam
  
  # Loop to compute the q values
  for (t in 2:n){
    q[t] <- beta1 + beta2 * q[t - 1] + beta3 * abs(returns[t - 1]) + beta4 * specx[t - 1]
  }
  return(q)
  # Calculate hit and loss
  hit <- (returns < q)
  loss <- (1 - alpha) * hit * (returns - q) + alpha * (1 - hit) * (q - returns)
  return(sum(loss))
}

#GARCH model
#using MLE method
garch_loglik <- function(params, returns,mu=0) {
  omega <- params[1]
  alpha <- params[2]
  beta <- params[3]
  
  n <- length(returns)
  sigma <- numeric(n)
  loglik <- 0
  
  sigma[1] <- var(returns)
  
  for (i in 2:n) {
    
    sigma[i] <- omega +  alpha* (returns[i - 1] - mu)^2 + beta* (sigma[i - 1])
    
    sigma[i] <- pmax(sigma[i], .Machine$double.eps)
    
    
    loglik <- loglik + dnorm(returns[i], mean = mu, sd = sqrt(sigma[i]), log = TRUE)
  }
  
  return(-loglik)  
}

#Garchx model
garchx_loglik <- function(params, returns, specx, mu=0) {
  
  omega <- params[1]
  alpha <- params[2]
  beta <- params[3]
  gamma <- params[4]
  
  n <- length(returns)
  sigma <- numeric(n)
  
  sigma[1] <- var(returns)
  loglik <- 0
  
  for (i in 2:n) {
    sigma[i] <- omega + beta* sigma[i-1] + alpha* (returns[i-1])^2 + gamma * specx[i-1]
    sigma[i] <- pmax(sigma[i], .Machine$double.eps)
    loglik <- loglik + dnorm(returns[i], mean = mu, sd = sqrt(sigma[i]), log = TRUE)
  }
  
  return(-loglik) 
}

#Forecast function for Garch model
ForecastGarch <- function(params, returns) {
  omega <- params[1]
  alpha <- params[2]
  beta <- params[3]
  
  n <- length(returns)
  sigma <- numeric(n)
  loglik <- 0
  
  sigma[1] <- var(returns)
  
  for (i in 2:n) {
    sigma[i] <- omega +  alpha* (returns[i - 1] )^2 + beta* (sigma[i - 1])
    sigma[i] <- pmax(sigma[i], .Machine$double.eps)
  }
  return(sigma)  
}

#in sample function for garchx

ForecastGarchx <- function(params, returns, vix) {
  
  omega <- params[1]
  alpha <- params[2]
  beta <- params[3]
  gamma <- params[4]
  
  n <- length(returns)
  sigma <- numeric(n)
  
  sigma[1] <- var(returns)
  
  loglik <- 0
  
  for (i in 2:n) {
    sigma[i] <- omega + beta* sigma[i-1] + alpha* (returns[i-1])^2 + gamma * vix[i-1]
    sigma[i] <- pmax(sigma[i], .Machine$double.eps)
    
  }
  
  return(sigma) 
}
OutForecastGarch <- function(params, returns, n_ahead) {
  omega <- params[1]    
  alpha <- params[2]    
  beta <- params[3]     
  
  n <- length(returns)          
  
  
  sigma <- numeric(n)   
  sigma[1] <- var(returns)
  
  
  for (i in 2:n) {
    sigma[i] <- omega + alpha * returns[i-1]^2 + beta * sigma[i-1]
  }
  
  
  for (i in (n+1):(n+n_ahead)) {
    sigma[i] <- omega+ alpha * returns[i-1]^2 + beta * sigma[i-1]
  }
  
  return(sigma)  
}

#Out of sample forecast function for Garchx model
OutForecastGarchx <- function(params, returns, vix, n_ahead) {
  # Estimated mean
  omega <- params[1]    
  alpha <- params[2]    
  beta <- params[3]     
  gamma<-params[4]
  n <- length(returns)          
  
  sigma <- numeric(n)   
  sigma[1] <- var(returns)
  for (i in 2:n) {
    sigma[i] <- omega + alpha * returns[i-1]^2 + beta * sigma[i-1] + gamma * vix[i-1]
  }
  for (i in (n+1):(n+n_ahead)) {
    sigma[i] <- omega+ alpha * returns[i-1]^2 + beta * sigma[i-1]+ gamma * vix[i-1]
  }
  return(sigma)  
}


## Function to calculate volatility from conditional variance
calculate_volatility <- function(conditional_variance) {
  # Volatility is the square root of the conditional variance
  volatility <- sqrt(conditional_variance)
  return(volatility)
}
# Function to calculate VaR
calculate_var <- function(volatility, alpha) {
  # Calculate the quantile of the normal distribution
  var <- qnorm(alpha, mean = 0, sd = volatility)
  return(var)
}
